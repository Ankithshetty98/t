import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Details from './components/Details';
import NavBar from './components/NavBar';
import Contact from './components/Contact';

function App() {
  return (
    <Router>
      <div className="App">
        <NavBar />
        <Routes>
           <Route path="/" element={<Details />} />
           <Route path="/contact" element={<Contact />}/>
        </Routes>
      </div>
    </Router>
  );
}

export default App;
