import React from 'react'
import './Contact.css';
const Contact = () => {
  return (
    <div>
           <div className="con">
                <div className="row TeleOrg">
                     <h5>Telephone/Organization</h5>
                        <div className="col-6">
                                <div className="row">
                                    <label className="col-lg-2 col-md-6 col-sm-6" htmlFor="givenName">First Name</label>
                                    <input className="col-lg-4 col-md-6 col-sm-6" name ="givenName" type="text" />
                                </div>
                                <div className="row">
                                    <label className="col-lg-2  col-md-6 col-sm-6" htmlFor="sn">Last Name</label>
                                    <input  className="col-lg-4 col-md-6 col-sm-6" name ="sn" type="text" />
                                </div>
                                <div className="row">
                                    <label className="col-lg-2 col-md-6 col-sm-6" htmlFor="samAccocuntName">Username</label>
                                    <input className="col-lg-4 col-md-6 col-sm-6" name ="samAccountName" type="text" />
                                </div>
                        </div>
                        <div className="col-6">
                                <div className="row">
                                    <label className="col-lg-2 col-md-6 col-sm-6" htmlFor="givenName">First Name</label>
                                    <input className="col-lg-4 col-md-6 col-sm-6" name ="givenName" type="text" />
                                </div>
                                <div className="row">
                                    <label className="col-lg-2  col-md-6 col-sm-6" htmlFor="sn">Last Name</label>
                                    <input  className="col-lg-4 col-md-6 col-sm-6" name ="sn" type="text" />
                                </div>
                                <div className="row">
                                    <label className="col-lg-2 col-md-6 col-sm-6" htmlFor="samAccocuntName">Username</label>
                                    <input className="col-lg-4 col-md-6 col-sm-6" name ="samAccountName" type="text" />
                                </div>
                        </div>
                </div>
                <div className="row Addr">
                <h5>Address</h5>
                    <div className="col-6">
                         <div className="row">
                            <label className="col-lg-2 col-md-6 col-sm-6" htmlFor="givenName">First Name</label>
                            <input className="col-lg-4 col-md-6 col-sm-6" name ="givenName" type="text" />
                        </div>
                        <div className="row">
                            <label className="col-lg-2  col-md-6 col-sm-6" htmlFor="sn">Last Name</label>
                            <input  className="col-lg-4 col-md-6 col-sm-6" name ="sn" type="text" />
                         </div>
                        <div className="row">
                            <label className="col-lg-2 col-md-6 col-sm-6" htmlFor="samAccocuntName">Username</label>
                            <input className="col-lg-4 col-md-6 col-sm-6" name ="samAccountName" type="text" />
                        </div>
                    </div>
                    <div className="row">
                        <button className="btn" type="submit">Submit</button>
                    </div>
                </div>
            </div>
    </div>
  )
}

export default Contact
