import React from 'react'
import './Details.css';
import {useNavigate} from 'react-router-dom';

const Details = () => {
  const navigate = useNavigate();
  function handleSubmit(e)
  {
    navigate('./contact');
  }
  return (
    <div>
      <div className="general">
        <h5>General Details</h5>
        <div className="gen">
             <form onSubmit={handleSubmit}>
                  <div className="row">
                      <label className="col-lg-2 col-md-6 col-sm-6" htmlFor="givenName">First Name</label>
                      <input className="col-lg-3 col-md-6 col-sm-6" name ="givenName" type="text" />
                  </div>
                  <div className="row">
                    <label className="col-lg-2  col-md-6 col-sm-6" htmlFor="sn">Last Name</label>
                    <input  className="col-lg-3 col-md-6 col-sm-6" name ="sn" type="text" />
                  </div>
                  <div className="row">
                    <label className="col-lg-2 col-md-6 col-sm-6" htmlFor="samAccocuntName">Username</label>
                    <input className="col-lg-3 col-md-6 col-sm-6" name ="samAccountName" type="text" />
                  </div>
                  <div className="row">  
                        <label className="col-lg-2 col-md-6 col-sm-6" htmlFor="description">Description</label>
                        <textarea rows="2" className="col-lg-3 col-md-6 col-sm-6" name="description"></textarea>
                  </div>
                  <button className="btn" type="submit">Next</button>
            </form>
        </div>
      </div>
    </div>
  )
}

export default Details
